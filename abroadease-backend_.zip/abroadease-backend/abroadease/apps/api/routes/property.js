import express from 'express';
import Property from '../models/Property.js';
import requireAuth from '../middleware/requireAuth.js';
import requireAdmin from '../middleware/requireAdmin.js';

const router = express.Router();

router.get('/', async (req, res) => {
  const { location, type, maxPrice } = req.query;
  const filter = {};
  if (location) filter.location = new RegExp(location, 'i');
  if (type) filter.type = type;
  if (maxPrice) filter.price = { $lte: Number(maxPrice) };

  const props = await Property.find(filter).sort({ createdAt: -1 });
  res.json(props);
});

router.get('/:id', async (req, res) => {
  const prop = await Property.findById(req.params.id);
  res.json(prop);
});

router.post('/', requireAuth, requireAdmin, async (req, res) => {
  const prop = await Property.create(req.body);
  res.json(prop);
});

router.put('/:id', requireAuth, requireAdmin, async (req, res) => {
  const prop = await Property.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(prop);
});

router.delete('/:id', requireAuth, requireAdmin, async (req, res) => {
  await Property.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

export default router;
